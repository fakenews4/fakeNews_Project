package com.example.fakenews;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FakenewsApplicationTests {

	@Test
	void contextLoads() {
	}

}
