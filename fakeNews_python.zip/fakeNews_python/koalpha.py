# from transformers import AutoModelForCausalLM, AutoTokenizer

# # 모델 이름 지정
# model_name = "beomi/KoAlpaca"

# # 모델과 토크나이저 다운로드 및 로컬 저장
# tokenizer = AutoTokenizer.from_pretrained(model_name, cache_dir="./models/koalpaca_model")
# model = AutoModelForCausalLM.from_pretrained(model_name, cache_dir="./models/koalpaca_model")

# print("모델 다운로드 완료!")
