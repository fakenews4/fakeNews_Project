package com.example.FakeNews;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FakeNewsApplicationTests {

	@Test
	void contextLoads() {
	}

}
